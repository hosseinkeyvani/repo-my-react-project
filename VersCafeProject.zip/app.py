import sqlite3

from flask import Flask, render_template, request, redirect


def init_db():
    conn = sqlite3.connect("db.sqlite3")
    with open("schema.sql", "r") as f:
        conn.executescript(f.read())
    conn.commit()
    conn.close()


def do_query(query, params=()):
    conn = sqlite3.connect("db.sqlite3")
    cursor = conn.cursor()
    cursor.execute(query, params)
    conn.commit()
    data = cursor.fetchall()
    cursor.close()
    conn.close()
    return data


app = Flask(__name__)


def all_orders():
    total = 0
    orders = do_query("SELECT TotalPrice FROM checkout")
    for order in orders:
        total += order[0]

    return total, len(orders)

@app.route("/")
def home():
    items = do_query("SELECT Name, Price, ID FROM menu")
    users = do_query("SELECT FirstName, LastName, Phone, ID FROM user")
    orders = do_query("SELECT checkout.UserID, user.FirstName AS UserFirstName, checkout.UserID, user.LastName AS UserLastName, checkout.quantity, checkout.ItemPrice, checkout.TotalPrice, menu.Name AS ItemName FROM checkout INNER JOIN menu ON menu.ID = checkout.ItemID INNER JOIN user ON user.ID = checkout.UserID")
    data = [len(users), all_orders()[0], all_orders()[1], len(items)]
    return render_template(template_name_or_list="index.html", items=items, users=users, orders=orders, stats=data)


@app.route("/item/add/", methods=['POST'])
def add_item():
    itemName = request.form.get("itemName")
    itemPrice = request.form.get("itemPrice")
    do_query("INSERT INTO menu(Name, Price) VALUES (?, ?)", (itemName, itemPrice))
    return redirect("/")


@app.route("/user/add/", methods=['POST'])
def add_user():
    customerName = request.form.get("customerName")
    customerFamily = request.form.get("customerFamily")
    customerPhone = request.form.get("customerPhone")
    do_query("INSERT INTO user(FirstName, LastName, Phone) VALUES (?, ?, ?)",
             (customerName, customerFamily, customerPhone))
    return redirect("/")


@app.route("/order/add/", methods=['POST'])
def add_order():
    customer_id = request.form.get("userName")
    item_id = request.form.get("itemName")
    item_price = do_query("SELECT Price, ID FROM menu WHERE ID = ?", (item_id,))[0][0]
    quantity = request.form.get("quantity")
    do_query("INSERT INTO checkout(UserID, quantity, ItemID, ItemPrice, TotalPrice) VALUES (?, ?, ?, ?, ?)",
             (int(customer_id), int(quantity), int(item_id), int(item_price), int(item_price) * int(quantity)))
    return redirect("/")

@app.route("/orders/")
def order():
    return "Orders are here!"


@app.route("/orders/<int:pk>/")
def last_orders(pk):
    return f"order {pk} is here!"


if __name__ == "__main__":
    init_db()
    print("Database initialized")
    # items = do_query("SELECT Name, Price, CategoryID FROM menu")
    # print(items[0][0])
